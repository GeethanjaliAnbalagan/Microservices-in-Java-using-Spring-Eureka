package com.geetha.microservice.HRService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrServiceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
