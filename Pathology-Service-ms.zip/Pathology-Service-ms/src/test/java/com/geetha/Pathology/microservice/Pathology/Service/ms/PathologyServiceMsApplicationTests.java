package com.geetha.Pathology.microservice.Pathology.Service.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PathologyServiceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
