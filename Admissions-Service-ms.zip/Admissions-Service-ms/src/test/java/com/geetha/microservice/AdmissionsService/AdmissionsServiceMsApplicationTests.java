package com.geetha.microservice.AdmissionsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmissionsServiceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
